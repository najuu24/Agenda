package com.exemplo.todo.service;

import com.exemplo.todo.entity.Task;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
public class TaskServiceTest {

    @Autowired
    private TaskService taskService;

    private Task task1;
    private Task task2;

    @BeforeEach
    public void setup() {
        taskService.deleteAllTasks();
        task1 = taskService.criarTask("Tarefa 1", "Descrição 1");
        task2 = taskService.criarTask("Tarefa 2", "Descrição 2");
    }

    @Test
    public void testGetAllTasks() {
        List<Task> tasks = taskService.listarTodas();
        assertEquals(2, tasks.size());
    }

    @Test
    public void testGetTaskById() {
        Optional<Task> task = taskService.getTaskById(task1.getId());
        assertTrue(task.isPresent());
        assertEquals("Tarefa 1", task.get().getTitulo());
        assertEquals("Descrição 1", task.get().getDescricao());
    }

    @Test
    public void testCreateTask() {
        Task task = taskService.criarTask("Tarefa 3", "Descrição 3");
        assertNotNull(task.getId());
        assertEquals("Tarefa 3", task.getTitulo());
        assertEquals("Descrição 3", task.getDescricao());
    }

    @Test
    public void testUpdateTask() {
        task1.setTitulo("Tarefa 1 Atualizada");
        task1.setDescricao("Descrição atualizada");
        Task updatedTask = taskService.updateTask(task1.getId(), task1);
        assertEquals("Tarefa 1 Atualizada", updatedTask.getTitulo());
        assertEquals("Descrição atualizada", updatedTask.getDescricao());
    }

    @Test
    public void testDeleteTask() {
        taskService.excluirTask(task1.getId());
        Optional<Task> deletedTask = taskService.getTaskById(task1.getId());
        assertFalse(deletedTask.isPresent());
    }

    @Test
    public void testDeleteAllTasks() {
        taskService.deleteAllTasks();
        List<Task> tasks = taskService.listarTodas();
        assertTrue(tasks.isEmpty());
    }

    @Test
    public void testMarcarComoConcluida() {
        Task concluida = taskService.marcarComoConcluida(task1.getId());
        assertTrue(concluida.isConcluida());
    }

    @Test
    public void testUpdateTaskNaoExistente() {
        Task fakeTask = new Task();
        fakeTask.setTitulo("Fake");
        fakeTask.setDescricao("Fake Desc");

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            taskService.updateTask(999L, fakeTask);
        });

        assertEquals("Task não encontrada!", exception.getMessage());
    }
}
