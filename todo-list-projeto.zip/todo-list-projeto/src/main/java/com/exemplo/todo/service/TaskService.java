package com.exemplo.todo.service;

import com.exemplo.todo.entity.Task;
import com.exemplo.todo.repository.TaskRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TaskService {

    private final TaskRepository repository;

    public TaskService(TaskRepository repository) {
        this.repository = repository;
    }

    // Criar task com título e descrição
    public Task criarTask(String titulo, String descricao) {
        Task task = new Task();
        task.setTitulo(titulo);
        task.setDescricao(descricao);
        task.setConcluida(false);
        return repository.save(task);
    }

    // Listar todas
    public List<Task> listarTodas() {
        return repository.findAll();
    }

    // Editar título
    public Task editarTitulo(Long id, String novoTitulo) {
        Task task = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Task não encontrada!"));
        task.setTitulo(novoTitulo);
        return repository.save(task);
    }

    // Marcar como concluída
    public Task marcarComoConcluida(Long id) {
        Task task = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Task não encontrada!"));
        task.setConcluida(true);
        return repository.save(task);
    }

    // Excluir task
    public void excluirTask(Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("Task não encontrada!");
        }
        repository.deleteById(id);
    }

    // Métodos auxiliares (opcionais)
    public void deleteAllTasks() {
        repository.deleteAll();
    }

    public Optional<Task> getTaskById(Long id) {
        return repository.findById(id);
    }

    public Task updateTask(Long id, Task updatedTask) {
        return repository.findById(id)
                .map(task -> {
                    task.setTitulo(updatedTask.getTitulo());
                    task.setDescricao(updatedTask.getDescricao());
                    task.setConcluida(updatedTask.isConcluida());
                    return repository.save(task);
                }).orElseThrow(() -> new RuntimeException("Task não encontrada!"));
    }
}
