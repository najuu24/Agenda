package com.exemplo.todo.controller;

import com.exemplo.todo.entity.Task;
import com.exemplo.todo.service.TaskService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tasks")
public class TaskController {

    private final TaskService service;

    public TaskController(TaskService service) {
        this.service = service;
    }

    // Criar nova task
    @PostMapping
    public Task criar(@RequestParam String titulo,
                      @RequestParam(required = false) String descricao) {
        return service.criarTask(titulo, descricao != null ? descricao : "");
    }

    // Listar todas
    @GetMapping
    public List<Task> listar() {
        return service.listarTodas();
    }

    // Editar título
    @PutMapping("/{id}")
    public Task editar(@PathVariable Long id,
                       @RequestParam String novoTitulo,
                       @RequestParam String descricao) {
        Task t = new Task();
        t.setTitulo(novoTitulo);
        t.setDescricao(descricao);
        return service.updateTask(id, t);
    }

    // Marcar como concluída
    @PatchMapping("/{id}/concluir")
    public Task concluir(@PathVariable Long id) {
        return service.marcarComoConcluida(id);
    }

    // Excluir task
    @DeleteMapping("/{id}")
    public void excluir(@PathVariable Long id) {
        service.excluirTask(id);
    }
}
